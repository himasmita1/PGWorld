<div class="footer">
    <div class="page-container footer-container">
        <div class="footer-cities">
            <div class="footer-city">
                <a href="property.php">PG in Delhi</a>
            </div>
            <div class="footer-city">
                <a href="property1.php">PG in Mumbai</a>
            </div>
            <div class="footer-city">
                <a href="property2.php">PG in Bangalore</a>
            </div>
            <div class="footer-city">
                <a href="property3.php">PG in Hyderabad</a>
            </div>
        </div>
        <div class="footer-copyright">© 2022 Copyright | Himasmita Boro | All Rights Reserved </div>
    </div>
</div>

<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/common.js"></script>

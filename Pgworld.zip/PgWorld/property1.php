<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Welcome | PG WORLD</title>

    <?php
    include "includes/head_links.php";
    ?>
    <link href="css/style1.css" rel="stylesheet" />
</head>

<body>
    <?php
    include "includes/header.php";
    ?>
    <nav aria-label="breadcrumb" style="position: fixed; width: 100%">
        <ol class="breadcrumb py-2">
            <li class="breadcrumb-item">
                <a href="index.php">Home</a>
            </li>
            <li class="breadcrumb-item active" aria-current="page">
                Mumbai
            </li>
        </ol>
    </nav>
    <div class="block1">
        <img src="img/room5.jpg">
        <div class="details"><h3>Pradise Hostel</h3>
        <p>Kalbadevi, Mumbai Pin-400002</p>
        <h4>Rs:5,500/-</h4>
        <button>View</button>
        </div>
    </div>
    <div class="block2">
        <img src="img/room6.jfif">
        <div class="details"><h3>Global Girls Hostel</h3>
        <p>Bandra, Mumbai, Pin-400007</p>
        <h4>Rs:6,500/-</h4>
        <button>View</button>
        </div>
    </div>
    <div class="block3">
        <img src="img/room2.jpg">
        <div class="details"><h3>Ujala Paying Guest</h3>
        <p>Mandvi, Mumbai, Pin-400005</p>
        <h4>Rs:5,000/-</h4>
        <button>View</button>
        </div>
    </div>
    <div class="block4">
        <img src="img/room1.jfif">
        <div class="details"><h3>Girl PG</h3>
        <p>Girgaon, Mumbai, Pin-400004</p>
        <h4>Rs:6,500/-</h4>
        <button>View</button>
        </div>
    </div>
    <?php
    include "includes/signup_modal.php";
    include "includes/login_modal.php";
    include "includes/footer.php";
    ?>

</body>

</html>

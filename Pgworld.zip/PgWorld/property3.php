<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Welcome | PG WORLD</title>

    <?php
    include "includes/head_links.php";
    ?>
    <link href="css/style1.css" rel="stylesheet" />
</head>

<body>
    <?php
    include "includes/header.php";
    ?>
    <nav aria-label="breadcrumb" style="position: fixed; width: 100%">
        <ol class="breadcrumb py-2">
            <li class="breadcrumb-item">
                <a href="index.php">Home</a>
            </li>
            <li class="breadcrumb-item active" aria-current="page">
                Hyderabad
            </li>
        </ol>
    </nav>
    <div class="block1">
        <img src="img/room9.jfif">
        <div class="details"><h3>Lagos House</h3>
        <p>Gandi Maisamma, Hyderabad</p>
        <h4>Rs:6,500/-</h4>
        <button>View</button>
        </div>
    </div>
    <div class="block2">
        <img src="img/room7.jfif">
        <div class="details"><h3>Hamburg House</h3>
        <p>Venkateshwara, Hyderabad-</p>
        <h4>Rs:7,500/-</h4>
        <button>View</button>
        </div>
    </div>
    <div class="block3">
        <img src="img/room5.jpg">
        <div class="details"><h3>Arlington House</h3>
        <p>Gachibowli Hyderabad</p>
        <h4>Rs:7,000/-</h4>
        <button>View</button>
        </div>
    </div>
    <div class="block4">
        <img src="img/room8.jpg">
        <div class="details"><h3>Exeter House</h3>
        <p>Gachibowli,Hyderabad,</p>
        <h4>Rs:4,500/-</h4>
        <button>View</button>
        </div>
    </div>
    <?php
    include "includes/signup_modal.php";
    include "includes/login_modal.php";
    include "includes/footer.php";
    ?>

</body>

</html>

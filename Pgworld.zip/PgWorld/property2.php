<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Welcome | PG WORLD</title>

    <?php
    include "includes/head_links.php";
    ?>
    <link href="css/style1.css" rel="stylesheet" />
</head>

<body>
    <?php
    include "includes/header.php";
    ?>

    <nav aria-label="breadcrumb" style="position: fixed; width: 100%">
        <ol class="breadcrumb py-2">
            <li class="breadcrumb-item">
                <a href="index.php">Home</a>
            </li>
            <li class="breadcrumb-item active" aria-current="page">
                Bengaluru
            </li>
        </ol>
    </nav>
    <div class="block1">
        <img src="img/room6.jfif">
        <div class="details"><h3>Dresden House</h3>
        <p>Koramangala,Bengaluru - 560029</p>
        <h4>Rs:7,500/-</h4>
        <button>View</button>
        </div>
    </div>
    <div class="block2">
        <img src="img/room7.jfif">
        <div class="details"><h3>Hamburg House</h3>
        <p>Venkateshwara, Bengaluru - 560019</p>
        <h4>Rs:8,500/-</h4>
        <button>View</button>
        </div>
    </div>
    <div class="block3">
        <img src="img/room1.jfif">
        <div class="details"><h3>Stavanger House</h3>
        <p>B7&B8 Silver pring Layout</p>
        <h4>Rs:7,000/-</h4>
        <button>View</button>
        </div>
    </div>
    <div class="block4">
        <img src="img/room4.jpg">
        <div class="details"><h3>Salzburg House</h3>
        <p>Suddagunte Palya, Bangalore</p>
        <h4>Rs:8,500/-</h4>
        <button>View</button>
        </div>
    </div>
    <?php
    include "includes/signup_modal.php";
    include "includes/login_modal.php";
    include "includes/footer.php";
    ?>

</body>

</html>

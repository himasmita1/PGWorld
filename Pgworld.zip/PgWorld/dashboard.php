<?php
session_start();
require "includes/database_connect.php";

if (!isset($_SESSION['email'])) {
    header("location: index.php");
    die();
}
$email = $_SESSION['email'];

$sql_1 = "SELECT * FROM users WHERE email = '$email'";
$result_1 = mysqli_query($conn, $sql_1);
if (!$result_1) {
    echo "Something went wrong!";
    return;
}
$user = mysqli_fetch_assoc($result_1);
if (!$user) {
    echo "Something went wrong!";
    return;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard | PG World</title>
    <?php
    include "includes/head_links.php";
    ?>
    <link href="css/dashboard.css" rel="stylesheet" />
</head>
<body>
    <?php
    include "includes/header.php";
    ?>
    <nav style="background-color: #001a33">
        <ol class="breadcrumb py-2">
            <li class="breadcrumb-item">
                <a href="index.php"><b>Home</b></a>
            </li>
            <li class="breadcrumb-item active" aria-current="page"><b>
                Dashboard
            </b></li>
        </ol>
    </nav>
    <div class="my-profile page-container">
        <h1>My Profile</h1>
        <div class="row">
            <div class="col-md-3 profile-img-container">
                <i class="fas fa-user profile-img"></i>
            </div>
            <div class="col-md-9">
                <div class="row no-gutters justify-content-between align-items-end">
                    <div class="profile">
                        <div class="name"><?php echo $user['full_name'];?></div>
                        <div class="email"><?php echo $user['email']; ?></div>
                        <div class="phone"><?php echo $user['phone']; ?></div>
                        <div class="college"><?php echo $user['college_name']; ?></div>
                    </div>
                    <div class="edit">
                        <div class="edit-profile">Edit Profile</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
